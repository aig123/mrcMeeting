import mrcIframeTab from './src/main';
mrcIframeTab.install = function(Vue) {
  Vue.component(mrcIframeTab.name, mrcIframeTab);
};
export default mrcIframeTab;
