import HhInputNumber from './src/main';
HhInputNumber.install = function(Vue) {
  Vue.component(HhInputNumber.name, HhInputNumber);
};
export default HhInputNumber;
