import mrcSearchForm from './src/main';
mrcSearchForm.install = function(Vue) {
  Vue.component(mrcSearchForm.name, mrcSearchForm);
};
export default mrcSearchForm;
