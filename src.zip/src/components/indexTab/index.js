
import indexTab from './src/main';
indexTab.install = function(Vue) {
  Vue.component(indexTab.name, indexTab);
};
export default indexTab;
