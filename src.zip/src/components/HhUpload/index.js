import HhUpload from './src/main';
HhUpload.install = function(Vue) {
  Vue.component(HhUpload.name, HhUpload);
};
export default HhUpload;
