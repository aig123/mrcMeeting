import HhImportant from './src/main';
HhImportant.install = function(Vue) {
  Vue.component(HhImportant.name, HhImportant);
};
export default HhImportant;
