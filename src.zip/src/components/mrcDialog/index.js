import mrcDialog from './src/main2';
mrcDialog.install = function(Vue) {
  Vue.component(mrcDialog.name, mrcDialog);
};
export default mrcDialog;
