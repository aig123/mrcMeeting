export const mentState = state => {
  return state.mentState;
}
export const currRouter = state => {
  return state.currRouter;
}
export const languageValue = state => {
  return state.languageValue;
}
export const phone = state => {
  return state.phone;
}
export const sHeight = state => {
  return state.sHeight;
}
